#ifndef MY_INCLUDES_H
#define MY_INCLUDES_H

#include <iostream>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include <limits>
#include <ctime>
#include <algorithm>
#include <random>
#include <omp.h>

#define ROUTE_MEM_ESTIMATE 10
//#define BOX_MIN_DIM 9 // determines the minimum width or length of bounding box, can be 32 say
//#define MAZE_ROUTE_ITER 1
//#define NUM_THREADS 4
#endif // MY_INCLUDES_H

